// 1. Live Countdown Timer (Target: 3 days from current time)
const targetDate = new Date();
targetDate.setDate(targetDate.getDate() + 3);

function updateCountdown() {
  const now = new Date().getTime();
  const difference = targetDate - now;

  if (difference > 0) {
    const days = Math.floor(difference / (1000 * 60 * 60 * 24));
    const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((difference % (1000 * 60)) / 1000);

    document.getElementById("days").innerText = days < 10 ? "0" + days : days;
    document.getElementById("hours").innerText = hours < 10 ? "0" + hours : hours;
    document.getElementById("minutes").innerText = minutes < 10 ? "0" + minutes : minutes;
    document.getElementById("seconds").innerText = seconds < 10 ? "0" + seconds : seconds;
  }
}
setInterval(updateCountdown, 1000);
updateCountdown();

// 2. Modal Controls
let currentSlotId = null;

function openModal(tournamentTitle, slotId) {
  document.getElementById("regModal").style.display = "flex";
  document.getElementById("modalTitle").innerText = tournamentTitle + " - Registration";
  currentSlotId = slotId;
}

function closeModal() {
  document.getElementById("regModal").style.display = "none";
}

window.onclick = function(event) {
  const modal = document.getElementById("regModal");
  if (event.target === modal) {
    closeModal();
  }
};

// 3. Form Submission & Slot Counter Update
document.getElementById("tournamentForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const teamName = document.getElementById("teamName").value;

  alert(`Success! Team "${teamName}" has been registered successfully.\nMatch credentials will be sent to your contact.`);

  // Dynamically increment slot count
  if (currentSlotId) {
    const slotElement = document.getElementById(currentSlotId);
    let currentText = slotElement.innerText; // e.g., "22 / 25 Registered"
    let parts = currentText.split(" / ");
    let filled = parseInt(parts[0]);
    let total = parseInt(parts[1]);

    if (filled < total) {
      filled += 1;
      slotElement.innerText = `${filled} / ${total} Registered`;
    }
  }

  this.reset();
  closeModal();
});
